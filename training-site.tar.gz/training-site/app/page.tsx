import Link from 'next/link'

export default function Home() {
  return (
    <main className="bg-gray-900 text-white min-h-screen">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 bg-black bg-opacity-90 backdrop-blur">
        <div className="max-w-6xl mx-auto px-6 py-4 flex justify-between items-center">
          <h1 className="text-2xl font-bold">Grapple & Lift</h1>
          <div className="space-x-8">
            <Link href="/" className="hover:text-blue-400 transition">
              Home
            </Link>
            <Link href="/contact" className="hover:text-blue-400 transition">
              Contact
            </Link>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="max-w-6xl mx-auto px-6 py-24 text-center">
        <h2 className="text-5xl font-bold mb-6">
          Train Like a Fighter. Build Like a Champion.
        </h2>
        <p className="text-xl text-gray-300 mb-8 max-w-3xl mx-auto">
          Grapple & Lift combines tactical conditioning, injury resistance training, and fight-ready preparation. Get stronger, tougher, and ready for anything.
        </p>
        <Link
          href="/contact"
          className="inline-block bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-8 rounded-lg transition text-lg"
        >
          Get Started
        </Link>
      </section>

      {/* Three Pillars */}
      <section className="bg-gray-800 py-20">
        <div className="max-w-6xl mx-auto px-6">
          <h3 className="text-4xl font-bold text-center mb-16">Our Program</h3>
          <div className="grid md:grid-cols-3 gap-8">
            {/* Tactical Conditioning */}
            <div className="bg-gray-700 p-8 rounded-lg">
              <h4 className="text-2xl font-bold mb-4 text-blue-400">
                Tactical Conditioning
              </h4>
              <p className="text-gray-300">
                Build explosive power, cardiovascular endurance, and mental toughness needed for real combat situations. Condition your body for peak performance under pressure.
              </p>
            </div>

            {/* Injury Resistance */}
            <div className="bg-gray-700 p-8 rounded-lg">
              <h4 className="text-2xl font-bold mb-4 text-blue-400">
                Injury Resistance
              </h4>
              <p className="text-gray-300">
                Strengthen joints, stabilize muscles, and correct imbalances. Our program builds a resilient body that can handle the demands of grappling and combat sports.
              </p>
            </div>

            {/* Fight Ready */}
            <div className="bg-gray-700 p-8 rounded-lg">
              <h4 className="text-2xl font-bold mb-4 text-blue-400">
                Fight Ready
              </h4>
              <p className="text-gray-300">
                Develop the physical and mental attributes needed to compete. Train with purpose and intensity to prepare yourself for competition day.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="max-w-6xl mx-auto px-6 py-24 text-center">
        <h3 className="text-4xl font-bold mb-6">Ready to Transform Your Training?</h3>
        <p className="text-xl text-gray-300 mb-8">
          Get in touch to learn more about our customized training programs.
        </p>
        <Link
          href="/contact"
          className="inline-block bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-8 rounded-lg transition text-lg"
        >
          Contact Us
        </Link>
      </section>

      {/* Footer */}
      <footer className="bg-black py-8 text-center text-gray-400">
        <p>&copy; 2025 Grapple & Lift. All rights reserved.</p>
      </footer>
    </main>
  )
}
