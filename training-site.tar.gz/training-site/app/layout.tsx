import type { Metadata } from 'next'
import './globals.css'

export const metadata: Metadata = {
  title: 'Grapple & Lift Training',
  description: 'Tactical conditioning, injury resistance, and fight readiness',
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  )
}
